a=input("enter your age:")
while(true):
    if a>=100:
        print ("invalid data")
    elif a<0:
        print ("invalid data")
    elif:
        if a>=18:
            print ("You can eligible to vote")
        else:
            print ("you cannot eligible to vote")
pass